The project went well, it's colorscheme is very bland (ie: nonexsistant) but the website is otherwise functional and looks very professional in my opinion.

Navigation I feel is very simple thanks to the collapsable sidebar, accessable from anywhere on the site.

Each page demonstrates a different feature from css or HTML,  making this a decent presentation of what I have learned

If I was to do the project again, I would have implemented styling features earlier in development, as trying to implement them late, like I did
only resulted in it being a headache to do so, forcing me to only do simple formatting features to keep the website consistant.

The twitter feeds, and google maps were implemented, with correct formatting, but could use some improvment in the presentation department again.

Overall, I think the project was a great learning experience, teaching me the value of planning ahead and creativity.



Project is online at: http://csiserver.ucd.ie/~17372013/final_project/home.html