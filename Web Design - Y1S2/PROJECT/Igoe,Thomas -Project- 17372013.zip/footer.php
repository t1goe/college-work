<?php
echo date("l jS \of F Y");
?>