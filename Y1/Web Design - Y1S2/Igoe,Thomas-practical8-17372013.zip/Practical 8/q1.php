<?php
	$myserver = $_SERVER['SERVER_NAME'];
	echo "Welcome to website at $myserver";
?>